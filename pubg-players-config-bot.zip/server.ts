import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { Telegraf, Markup } from "telegraf";
import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs, doc, getDoc, query, orderBy, where } from "firebase/firestore";
import fs from "fs";

// Load Firebase Config
const firebaseConfigPath = path.join(process.cwd(), "firebase-applet-config.json");
const firebaseConfig = JSON.parse(fs.readFileSync(firebaseConfigPath, "utf-8"));

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');

const PORT = process.env.PORT || 3000;

async function startServer() {
  const expressApp = express();

  // Initialize Telegram Bot
  const token = process.env.TELEGRAM_BOT_TOKEN;
  let bot: Telegraf | null = null;

  if (token && token !== "YOUR_BOT_TOKEN") {
    bot = new Telegraf(token);

    // Bot Handlers
    bot.start(async (ctx) => {
      try {
        if (!db) {
          throw new Error("Firestore DB not initialized");
        }
        const playersRef = collection(db, "players");
        const q = query(
          playersRef, 
          where("isVisible", "==", true),
          orderBy("createdAt", "desc")
        );
        const snapshot = await getDocs(q);
        const players = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

        if (players.length === 0) {
          return ctx.reply("Hozircha hech qanday o'yinchi qo'shilmagan.");
        }

        const buttons = players.map((p: any) => [Markup.button.callback(p.name, `player_${p.id}`)]);
        
        await ctx.reply(
          "Assalomu alaykum! PUBG mashhur o'yinchilari ro'yxati. Birontasini tanlang:",
          Markup.inlineKeyboard(buttons)
        );
      } catch (error) {
        console.error("Bot Start Error:", error);
        ctx.reply("Xatolik yuz berdi. Iltimos keyinroq urinib ko'ring.");
      }
    });

    bot.on("callback_query", async (ctx) => {
      const data = (ctx.callbackQuery as any).data;
      if (data.startsWith("player_")) {
        const playerId = data.split("_")[1];
        try {
          if (!db) {
            throw new Error("Firestore DB not initialized");
          }
          const playerDoc = await getDoc(doc(db, "players", playerId));
          if (playerDoc.exists()) {
            const player = playerDoc.data();
            const message = `
🌟 *O'yinchi:* ${player.name}
📱 *Upravlenya kodi:* \`${player.layoutCode}\`
🎯 *Chust kodi:* \`${player.sensitivityCode}\`
`;
            if (player.photoUrl) {
              await ctx.replyWithPhoto(player.photoUrl, {
                caption: message,
                parse_mode: "Markdown",
              });
            } else {
              await ctx.reply(message, { parse_mode: "Markdown" });
            }
          } else {
            await ctx.answerCbQuery("O'yinchi topilmadi.");
          }
        } catch (error) {
          console.error("Bot Callback Error:", error);
          await ctx.answerCbQuery("Xatolik yuz berdi.");
        }
      }
    });

    // Launch bot with retry logic
    const launchBot = async (retries = 5, delay = 2000) => {
      try {
        await bot?.launch();
        console.log("Telegram bot started successfully");
      } catch (error: any) {
        if (retries > 0) {
          console.error(`Bot launch failed: ${error.message}. Retrying in ${delay}ms... (${retries} attempts left)`);
          setTimeout(() => launchBot(retries - 1, delay * 2), delay);
        } else {
          console.error("Bot failed to start after multiple attempts:", error);
        }
      }
    };

    launchBot();
  } else {
    console.warn("TELEGRAM_BOT_TOKEN is missing or default. Bot not started.");
  }

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    expressApp.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    expressApp.use(express.static(distPath));
    expressApp.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  expressApp.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Graceful stop
  process.once("SIGINT", () => bot?.stop("SIGINT"));
  process.once("SIGTERM", () => bot?.stop("SIGTERM"));
}

startServer().catch(console.error);
