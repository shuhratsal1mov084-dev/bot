# Security Specification - PUBG Players Bot

## Data Invariants
1. A player must have a unique ID, a name, a photo URL, a sensitivity code, and a layout code.
2. Only authorized administrators (verified via email or specific UID) can modify the player database.
3. Public users (via the bot or web viewer) can read player data but cannot modify it.

## The "Dirty Dozen" Payloads (Denial Tests)
1. **Unauthenticated Create:** Attemping to add a player without being logged in.
2. **Identity Spoofing:** Attemping to create a player with another user's ID as owner (if ownership is used).
3. **Ghost Field Update:** Adding `isVerified: true` to a player document.
4. **Invalid Type (Name):** Sending an integer as the player's name.
5. **Oversized String:** Sending a 1MB string as a sensitivity code (Denial of Wallet).
6. **Negative Timestamp:** Sending a future or invalid timestamp for `createdAt`.
7. **Malicious ID:** Using a 1.5KB string with junk characters as a player ID.
8. **Missing Required Field:** Creating a player without a `layoutCode`.
9. ** unauthorized Delete:** A guest attempting to delete a player.
10. **Admin Field Modification:** A non-admin attempting to change their own role (if roles exist).
11. **Path Poisoning:** Injecting `../` into path variables.
12. **Public Write:** Blanket permission allowing any signed-in user to write to anyone's data.

## Test Runner
Verified via `firestore.rules.test.ts` (conceptual).
