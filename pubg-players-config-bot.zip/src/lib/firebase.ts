import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import firebaseConfig from '../../firebase-applet-config.json';

// Debug: ensure config is loaded
console.log("Firebase Config:", firebaseConfig);

const app = initializeApp(firebaseConfig);

if (!firebaseConfig.projectId) {
  console.error("Firebase config failed to load correctly!", firebaseConfig);
}

const dbId = firebaseConfig.firestoreDatabaseId || '(default)';
export const db = getFirestore(app, dbId);
export const auth = getAuth(app);
export const storage = getStorage(app, `gs://${firebaseConfig.storageBucket}`);

// Sign in anonymously to handle Storage permissions
signInAnonymously(auth).catch(err => {
  console.warn("Anonymous sign-in failed:", err);
});
