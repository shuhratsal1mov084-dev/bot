import React, { useState, useEffect } from 'react';
import { 
  collection, 
  addDoc, 
  onSnapshot, 
  deleteDoc, 
  doc, 
  updateDoc,
  serverTimestamp,
  query,
  orderBy,
  getDocFromServer
} from 'firebase/firestore';
import { 
  ref, 
  uploadBytes, 
  getDownloadURL,
  deleteObject
} from 'firebase/storage';
import { db, storage } from './lib/firebase';
import { 
  Plus, 
  Trash2, 
  LogOut, 
  User as UserIcon, 
  Gamepad2, 
  Settings2, 
  Layout, 
  Image as ImageIcon,
  Loader2,
  AlertCircle,
  Lock,
  CheckCircle2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// --- Components ---

function Login({ onLogin }: { onLogin: () => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Try both import.meta.env and process.env (mapped in vite.config)
    const correctPassword = process.env.VITE_ADMIN_PASSWORD || import.meta.env.VITE_ADMIN_PASSWORD || 'admin';
    
    if (password.trim() === correctPassword.trim()) {
      onLogin();
      localStorage.setItem('admin_authenticated', 'true');
    } else {
      setError("Parol noto'g'ri! Agar o'zgartirmagan bo'lsangiz, standart parol: admin");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0F172A] px-4 font-sans">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-sm w-full bg-[#1E293B] rounded-3xl shadow-[0_0_50px_rgba(6,182,212,0.1)] p-10 border border-slate-700 relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-[#06B6D4]"></div>
        
        <div className="flex flex-col items-center text-center mb-10">
          <div className="w-20 h-20 bg-[#06B6D4] rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_20px_rgba(6,182,212,0.4)]">
            <Gamepad2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tight uppercase">
            PUBG BOT <span className="text-[#06B6D4]">ADMIN</span>
          </h1>
          <p className="text-slate-400 mt-3 text-xs uppercase tracking-widest font-mono">Boshqaruv Paneli</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-rose-500/10 text-rose-400 rounded-xl text-xs flex items-center gap-3 border border-rose-500/20">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="password"
              required
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Admin paroli"
              className="w-full pl-10 pr-4 py-4 bg-slate-800/80 border border-slate-600 rounded-xl text-white focus:outline-none focus:border-[#06B6D4] transition-all"
            />
          </div>
          <button
            type="submit"
            className="w-full bg-[#06B6D4] text-white py-4 rounded-xl font-black uppercase tracking-wider hover:bg-[#0891b2] transition-all shadow-lg shadow-cyan-900/20 active:scale-95"
          >
            Kirish
          </button>
        </form>

        <p className="text-center text-[10px] text-slate-500 mt-8 uppercase tracking-widest font-mono">
          Google Login Olib Tashlandi
        </p>
      </motion.div>
    </div>
  );
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [players, setPlayers] = useState<any[]>([]);
  const [newPlayer, setNewPlayer] = useState({
    name: '',
    sensitivityCode: '',
    layoutCode: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  useEffect(() => {
    // Session check
    const isAuth = localStorage.getItem('admin_authenticated');
    if (isAuth === 'true') {
      setIsAuthenticated(true);
    }
    
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error: any) {
        if (error.message?.includes('the client is offline')) {
          console.error("Please check your Firebase configuration.");
        }
      }
    };
    testConnection();
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!isAuthenticated) return;

    if (!db) {
      console.error("Firestore database instance is not initialized!");
      return;
    }

    try {
      console.log("Setting up Firestore snapshot listener for collection 'players'...");
      const q = query(collection(db, 'players'), orderBy('createdAt', 'desc'));
      const unsubscribePlayers = onSnapshot(q, (snapshot) => {
        console.log("Snapshot received! Count:", snapshot.size);
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setPlayers(data);
      }, (error) => {
        console.error("Firestore Snapshot Error:", error);
        alert("Firestore yuklashda xatolik: " + error.message);
      });

      return () => unsubscribePlayers();
    } catch (err: any) {
      console.error("Error setting up snapshot:", err);
      alert("Snapshot sozlashda xatolik: " + err.message);
    }
  }, [isAuthenticated]);

  const handleAddPlayer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlayer.name || !newPlayer.sensitivityCode || !newPlayer.layoutCode) {
      alert("Iltimos, hamma maydonlarni to'ldiring!");
      return;
    }

    if (!db) {
      alert("Ma'lumotlar bazasi bilan muammo! Sahifani yangilab ko'ring.");
      setIsSubmitting(false);
      return;
    }

    setIsSubmitting(true);
    console.log("Starting player addition process...");
    try {
      console.log("Adding document to Firestore...");
      const docRef = await addDoc(collection(db, 'players'), {
        ...newPlayer,
        photoUrl: '', // Explicitly empty
        isVisible: true, // Default to visible in bot
        createdAt: serverTimestamp()
      });
      console.log("Player added with ID:", docRef.id);

      setNewPlayer({ name: '', sensitivityCode: '', layoutCode: '' });
      setSuccessMessage("O'yinchi muvaffaqiyatli qo'shildi!");
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (error: any) {
      console.error("Write Error details:", error);
      alert("Xatolik qo'shishda: " + (error.message || "Noma'lum xato"));
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleVisibility = async (player: any) => {
    if (!db) return;
    try {
      await updateDoc(doc(db, 'players', player.id), {
        isVisible: !player.isVisible
      });
    } catch (error) {
      console.error("Toggle Error:", error);
    }
  };

  const handleDeletePlayer = async (player: any) => {
    if (!confirm("O'yinchini o'chirib tashlamoqchimisiz?")) return;
    
    if (!db) {
      alert("Ma'lumotlar bazasi bilan muammo!");
      return;
    }

    try {
      // Delete from Firestore
      await deleteDoc(doc(db, 'players', player.id));
      alert("O'yinchi o'chirildi!");
    } catch (error) {
      console.error("Delete Error:", error);
      alert("O'chirishda xatolik yuz berdi!");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_authenticated');
    setIsAuthenticated(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-[#06B6D4] animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Login onLogin={() => setIsAuthenticated(true)} />;
  }

  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100 font-sans flex flex-col">
      {/* Header */}
      <header className="h-20 bg-[#1E293B] border-b-4 border-[#06B6D4] shrink-0 sticky top-0 z-50 shadow-xl">
        <div className="max-w-[1400px] mx-auto h-full px-8 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-[#06B6D4] rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.4)]">
              <Gamepad2 className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-black tracking-tight text-white uppercase leading-none">
                PUBG BOT <span className="text-[#06B6D4]">ADMIN</span>
              </h1>
              <p className="text-[10px] text-slate-400 font-mono mt-1 opacity-60">
                ACTIVE SESSION: ADMIN
              </p>
            </div>
          </div>
          <div className="flex gap-6 items-center">
            <div className="text-right hidden sm:block">
              <p className="text-[10px] uppercase font-bold text-slate-500 tracking-widest">Bot Status</p>
              <p className="text-[#10B981] font-bold flex items-center justify-end gap-2 text-xs">
                <span className="w-1.5 h-1.5 bg-[#10B981] rounded-full animate-pulse"></span> ONLINE
              </p>
            </div>
            <button 
              onClick={handleLogout}
              className="bg-rose-500 hover:bg-rose-600 px-4 py-2 rounded-lg font-black text-xs transition-all uppercase tracking-widest active:scale-95"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex flex-col lg:flex-row max-w-[1400px] w-full mx-auto p-4 lg:p-8 gap-8 overflow-y-auto lg:overflow-hidden">
        {/* Detail Panel: Add Player - Show first on mobile */}
        <section className="flex flex-col gap-4 order-1 lg:order-2 lg:flex-1">
          <h2 className="text-lg font-black text-[#FBBF24] mb-1 uppercase tracking-tighter italic px-2">Yangi o'yinchi qo'shish</h2>
          <div className="bg-[#1E293B] rounded-2xl border border-slate-700 p-6 lg:p-10 shadow-inner relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#06B6D4] opacity-5 rounded-full -mr-16 -mt-16 blur-3xl"></div>
            
            <form onSubmit={handleAddPlayer} className="grid grid-cols-1 sm:grid-cols-2 gap-6 lg:gap-8 relative z-10">
              {successMessage && (
                <div className="col-span-full p-4 bg-green-500/10 text-green-400 rounded-xl text-xs flex items-center gap-3 border border-green-500/20 mb-2 animate-bounce">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  {successMessage}
                </div>
              )}
              <div className="col-span-full flex flex-col gap-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">O'yinchi Ismi</label>
                <input 
                  type="text" 
                  autoFocus
                  required
                  value={newPlayer.name}
                  onChange={e => setNewPlayer({ ...newPlayer, name: e.target.value })}
                  placeholder="Masalan: Levinho" 
                  className="bg-slate-800/80 border border-slate-600 rounded-xl px-5 py-4 text-white focus:outline-none focus:border-[#06B6D4] focus:ring-1 focus:ring-[#06B6D4] transition-all placeholder:text-slate-600 w-full"
                />
              </div>
              
              <div className="flex flex-col gap-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Chust kodi (Sensitivity)</label>
                <input 
                  type="text" 
                  required
                  value={newPlayer.sensitivityCode}
                  onChange={e => setNewPlayer({ ...newPlayer, sensitivityCode: e.target.value })}
                  placeholder="7008-2321-12..." 
                  className="bg-slate-800/80 border border-slate-600 rounded-xl px-5 py-4 text-white focus:outline-none focus:border-[#06B6D4] focus:ring-1 focus:ring-[#06B6D4] transition-all placeholder:text-slate-600 font-mono text-sm uppercase w-full"
                />
              </div>

              <div className="flex flex-col gap-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Upravlena kodi (Control)</label>
                <input 
                  type="text" 
                  required
                  value={newPlayer.layoutCode}
                  onChange={e => setNewPlayer({ ...newPlayer, layoutCode: e.target.value })}
                  placeholder="6982-1234-90..." 
                  className="bg-slate-800/80 border border-slate-600 rounded-xl px-5 py-4 text-white focus:outline-none focus:border-[#06B6D4] focus:ring-1 focus:ring-[#06B6D4] transition-all placeholder:text-slate-600 font-mono text-sm uppercase w-full"
                />
              </div>

              <div className="col-span-full pt-4 lg:pt-10 flex flex-col sm:flex-row gap-4">
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 bg-[#06B6D4] hover:bg-[#0891b2] text-white font-black py-4 rounded-xl shadow-lg shadow-cyan-900/40 transition-all uppercase tracking-widest disabled:opacity-50 flex items-center justify-center gap-3 active:scale-95"
                >
                  {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Plus className="w-5 h-5" />}
                  Botga Qo'shish
                </button>
                <button 
                  type="button"
                  onClick={() => {
                    setNewPlayer({ name: '', sensitivityCode: '', layoutCode: '' });
                  }}
                  className="px-8 py-4 lg:py-2 bg-slate-700 hover:bg-slate-600 font-black rounded-xl transition-colors uppercase tracking-widest text-xs"
                >
                  Tozalash
                </button>
              </div>
            </form>
          </div>
        </section>

        {/* Sidebar: Player List */}
        <section className="w-full lg:w-1/3 flex flex-col gap-4 order-2 lg:order-1 h-fit lg:h-full lg:overflow-hidden">
          <div className="flex justify-between items-end mb-1 px-2">
            <h2 className="text-lg font-black text-[#FBBF24] uppercase tracking-tighter italic">O'yinchilar Ro'yxati</h2>
            <span className="bg-slate-800 text-slate-400 text-[10px] px-2 py-1 rounded font-mono">JAMI: {players.length}</span>
          </div>
          
          <div className="max-h-[500px] lg:max-h-none lg:flex-1 bg-[#1E293B]/50 rounded-2xl border border-slate-700/50 p-4 flex flex-col gap-3 overflow-y-auto custom-scrollbar">
            <AnimatePresence mode="popLayout">
              {players.map((player) => (
                <motion.div
                  key={player.id}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="bg-slate-800/40 border-l-4 border-slate-600 p-4 rounded-r-xl flex items-center gap-4 group hover:bg-[#06B6D4]/5 hover:border-[#06B6D4] transition-all cursor-default"
                >
                  <div className="w-12 h-12 bg-slate-700 rounded-full border-2 border-slate-600 overflow-hidden shrink-0 group-hover:border-[#06B6D4] transition-colors flex items-center justify-center">
                    <UserIcon className="w-5 h-5 text-slate-500" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-black text-white uppercase text-sm truncate">{player.name}</p>
                    <p className="text-[10px] text-slate-500 font-mono mt-1 group-hover:text-[#06B6D4]/70 truncate tracking-tight">
                      {player.layoutCode?.split('-')[0]}-... / {player.sensitivityCode?.split('-')[0]}-...
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={() => toggleVisibility(player)}
                      className={`p-2 rounded-lg transition-all ${player.isVisible ? 'bg-green-500/20 text-green-500' : 'bg-slate-700 text-slate-500'}`}
                      title={player.isVisible ? "Botda ko'rinmoqda" : "Botda yashirilgan"}
                    >
                      <CheckCircle2 className={`w-5 h-5 ${player.isVisible ? 'opacity-100' : 'opacity-30'}`} />
                    </button>
                    <button 
                      onClick={() => handleDeletePlayer(player)}
                      className="text-slate-600 hover:text-rose-500 transition-colors p-2"
                    >
                      <Trash2 className="w-5 h-5 opacity-40 hover:opacity-100" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>

            {players.length === 0 && (
              <div className="flex-1 flex flex-col items-center justify-center opacity-20 grayscale py-10">
                <Gamepad2 className="w-16 h-16 mb-4" />
                <p className="uppercase font-black text-xs tracking-widest">Ma'lumot yo'q</p>
              </div>
            )}
          </div>
        </section>
      </main>

      {/* Stats Footer */}
      <footer className="h-12 bg-[#0F172A] border-t border-slate-800 px-8 flex items-center justify-between text-[10px] text-slate-500 font-mono shrink-0">
        <div className="flex gap-8 uppercase tracking-tighter">
          <span className="flex items-center gap-2"><div className="w-1 h-1 bg-cyan-500 rounded-full"></div> PLAYERS: {players.length}</span>
          <span className="flex items-center gap-2"><div className="w-1 h-1 bg-green-500 rounded-full"></div> SYSTEM ACTIVE</span>
          <span className="flex items-center gap-2"><div className="w-1 h-1 bg-amber-500 rounded-full"></div> REGION: ASIA</span>
        </div>
        <div className="opacity-40">
          POWERED BY TELEGRAM BOT API • v4.2.1
        </div>
      </footer>
    </div>
  );
}
